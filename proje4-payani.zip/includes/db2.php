<?php
$conn = new mysqli("alvand.liara.cloud", "moein", "9cae5b58-8007-4f84-8505-f209c72676d2", "xenodochial_goldberg");
if ($conn->connect_error) {
    die("اتصال به دیتابیس ناموفق: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");
?>